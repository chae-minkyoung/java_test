package mission0125;

public class mission0125_2{ 
	public static void main(String[] args) { 
//		byte var1=128; //A. byte는 127까지만 가능하기때문에 오류. -128~127 사이의 값이면 오류가 없어질 것임.
//		short var2=128; //B. 
//		long var3=28L; //C.  int는 정수 값만 입력 가능한데 28L이라는 long의 값을 입력해서 오류. 28까지만 입력하면 오류가 없어질 것임. 
//		long var4=128L; //D. 
//		float var5=123456.789123; //E.float가 가져올 때 8B값을 가져와서 오류. 앞의 float를 double로 바꿔주거나 숫자 뒤에 f를 붙이면 오류가 없어질 것임.
//		double var6=123456.789123; //F.
} 
}


