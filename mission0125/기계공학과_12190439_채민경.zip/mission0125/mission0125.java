//package mission0125;
//
//public class mission0125 { 
//	public static void main(String[] args) { 
//		char a='a'; //A. 
//		char b="a"; //B. B에서 " " 사이에 들어있는 것은 str로 인식하기 때문에 'a'로 바꿔주거나 앞의 char을 String로 바꿔줘야 함.
//		String c="a"; //C. 
//		String d='a'; //D. ' ' 사이에 있는 것은 char로 인식하기 때문에 앞의 String을 char로 바꿔주거나 "a"로 바꿔줘야 함.  
//		char e='ab'; //E.  char은 캐릭터 하나만을 인식하기 때문에 String = "ab"로 바꿔줘야 함.  
//		String f="ab"; //F.
//} 
//}



